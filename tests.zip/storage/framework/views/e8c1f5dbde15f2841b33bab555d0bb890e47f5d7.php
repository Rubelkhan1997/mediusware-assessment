<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Product</h1>
    </div>
     <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('product.store')); ?>" method="post" autocomplete="off" spellcheck="false" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <section>
            <div class="row">
                <div class="col-md-6">
                    <!--                    Product-->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Product</h6>
                        </div>
                        <div class="card-body border">
                            <div class="form-group">
                                <label for="product_name">Product Name</label>
                                <input type="text" name="product_name" value="<?php echo e($product->title); ?>" class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product_name" placeholder="Product Name">
                                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="product_sku">Product SKU</label>
                                <input type="text" name="product_sku" value="<?php echo e($product->sku); ?>"  class="form-control <?php $__errorArgs = ['product_sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product_sku" placeholder="Product Name" class="form-control">
                                <?php $__errorArgs = ['product_sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-0">
                                <label for="product_description">Description</label>
                                <textarea name="product_description" value="<?php echo e($product->description); ?>" class="form-control <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product_description" rows="4"><?php echo e($product->description); ?></textarea>
                                <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <!--                    Media-->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"><h6
                                class="m-0 font-weight-bold text-primary">Media</h6></div>
                        <div class="card-body border  <?php $__errorArgs = ['product_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <div id="file-upload" class="dropzone dz-clickable mb-2">
                                <div class="dz-default dz-message"><span>Drop files here to upload</span></div>
                            </div>
                            <?php $__errorArgs = ['product_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:red"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__currentLoopData = (object) $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(url($p)); ?>" alt="Not Found" width="100" height="100">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>   
                        <input type="hidden" name="product_photo" value="<?php echo e(implode(' ', $product->photos)); ?>">    
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">    
                    </div>
                </div>
                <!--                Variants-->
                <div class="col-md-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Variants</h6>
                        </div>
                        <div class="card-body pb-0" id="variant-sections">
                            
                        </div>
                        <div class="card-footer bg-white border-top-0" id="add-btn">
                            <div class="row d-flex justify-content-center">
                                <button class="btn btn-primary add-btn" onclick="addVariant(event);">
                                    Add another option
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header text-uppercase">Preview</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr class="text-center">
                                        <th width="33%">Variant</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                    </tr>
                                    </thead>
                                    <tbody id="variant-previews">
                                        <?php $__currentLoopData = $product->variant_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th>
                                                    <input type="hidden" name="product_preview[<?php echo e($key); ?>][variant]" value="<?php echo e($price->title); ?>">
                                                    <span class="font-weight-bold"><?php echo e($price->title); ?></span>
                                                </th>
                                                <td>
                                                    <input type="number" name="product_preview[<?php echo e($key); ?>][price]" value="<?php echo e(number_format($price->price,2)); ?>" class="form-control" required>
                                                </td>
                                                <td>
                                                    <input type="number" name="product_preview[<?php echo e($key); ?>][stock]" value="<?php echo e($price->stock); ?>" class="form-control" required>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="sumbit" class="btn btn-lg btn-primary">Save</button>
            <button type="button" class="btn btn-secondary btn-lg">Cancel</button>
        </section>
    </form>
<?php $__env->stopSection(); ?>

<input type="hidden" name="variant_selector" value="<?php echo e(json_encode($product->variants, true)); ?>">

<?php $__env->startPush('page_js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/product.js')); ?>"></script>
    <script>
        $(function(){
            $('#variant-sections').html("");
            let variant_selector = $('input[name=variant_selector]').val();
            let index = 0;
            indexs = [];
            // Foreach
            $.each(JSON.parse(variant_selector) , function(variant_id, val) { 
                $("#variant-sections").append(`<div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Option</label>
                                                <select id="select2-option-${index}" data-index="${index}" name="product_variant[${index}][option]" class="form-control custom-select select2 select2-option" required>
                                                    <option value="1">
                                                        Color
                                                    </option>
                                                    <option value="2">
                                                        Size
                                                    </option>
                                                    <option value="6">
                                                        Style
                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label class="d-flex justify-content-between">
                                                    <span>Value</span>
                                                    <a href="#" class="remove-btn" data-index="${index}" onclick="removeVariant(event, this);">Remove</a>
                                                </label>
                                                <select id="select2-value-${index}" data-index="${index}" name="product_variant[${index}][value][]" class="select2 select2-value form-control custom-select" multiple="multiple" required>
                                                </select>
                                            </div>
                                        </div>
                                    </div>`);

                
                $(`#select2-option-${index}`).select2({placeholder: "Select Option", theme: "bootstrap4"});
                $(`#select2-value-${index}`).select2({ 
                    tags: true, 
                    multiple: true,
                    placeholder: "Type tag name", 
                    allowClear: true, 
                    theme: "bootstrap4"
                }).on('change', function () {
                    updateVariantPreview(1);
                });

                $(`#select2-option-${index}`).val(variant_id).trigger('change')    
                $.each(val, function(i, v) { 
                    $(`#select2-value-${index}`).append(`<option value='${v}'}>${v}</option>`);   
                });
                $(`#select2-value-${index}`).val(val).trigger('change')   

                
                indexs.push(index);
                currentIndex = (index +1);
                if (indexs.length >= 3) {
                    $("#add-btn").hide();
                } else {
                    $("#add-btn").show();
                }
                index++;
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\mediusware-assessment\resources\views/products/edit.blade.php ENDPATH**/ ?>