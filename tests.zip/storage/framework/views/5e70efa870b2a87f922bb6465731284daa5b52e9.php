<?php $__env->startSection('content'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Products</h1>
    </div>
    <div class="card">
        <form action="" method="get" class="card-header">
            <div class="form-row justify-content-between">
                <div class="col-md-2">
                    <input type="text" name="title" value="<?php echo e(Request::get('title')); ?>" placeholder="Product Title" class="form-control">
                </div>
                <div class="col-md-2">
                    <select name="variant" class="form-control">
                        <option disabled selected>-- Select A Variant --</option>
                        <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <optgroup label="<?php echo e($variant->title); ?>">
                            <?php $__currentLoopData = $variant->product_variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_varient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(Request::get('variant') == $p_varient->variant? 'selected' : ''); ?> value="<?php echo e($p_varient->variant); ?>">
                                    <?php echo e($p_varient->variant); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>

                <div class="col-md-3">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Price Range</span>
                        </div>
                        <input type="text" name="price_from" value="<?php echo e(Request::get('price_from')); ?>" aria-label="First name" placeholder="From" class="form-control">
                        <input type="text" name="price_to"   value="<?php echo e(Request::get('price_to')); ?>"   aria-label="Last name" placeholder="To" class="form-control">
                    </div>
                </div>
                <div class="col-md-2">
                    <input type="date" name="date" value="<?php echo e(Request::get('date')); ?>" placeholder="Date" class="form-control">
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary float-left"><i class="fa fa-search"></i></button>
                    
                </div>
            </div>
        </form>

        <div class="card-body">
            <div class="table-response">
                <table class="table">
                    <thead>
                    <tr>
                        <th style="width: 5%">#</th>
                        <th style="width: 20%">Title</th>
                        <th style="width: 20%">Description</th>
                        <th style="width: 45%">Variant</th>
                        <th style="width: 10%">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php
                                foreach ($p->variants as $v) {
                                    $variant[$v->id] = $v->variant; 
                                }
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($p->title); ?> <br> Created at : <?php echo e(date('d-M-Y', strtotime($p->created_at))); ?></td>
                                <td><?php echo e(Str::limit($p->description, 100, '...')); ?></td>
                                <td>
                                    <dl class="row mb-0" style="height: 80px; overflow: hidden" id="variant<?php echo e($p->id); ?>">
                                        <?php $__currentLoopData = $p->variant_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $v_title  = isset($variant[$pri->product_variant_one])? $variant[$pri->product_variant_one] : null;
                                            $v_title .= isset($variant[$pri->product_variant_two])? '/'.$variant[$pri->product_variant_two] : null;
                                            $v_title .= isset($variant[$pri->product_variant_three])? '/'.$variant[$pri->product_variant_three] : null;   
                                        ?>
                                        <dt class="col-sm-3 pb-0">
                                            <?php echo e($v_title); ?> 
                                       </dt>
                                        <dd class="col-sm-9">
                                            <dl class="row mb-0">
                                                <dt class="col-sm-4 pb-0">Price : <?php echo e(number_format($pri->price,2)); ?></dt>
                                                <dd class="col-sm-8 pb-0">InStock : <?php echo e($pri->stock); ?></dd>
                                            </dl>
                                        </dd>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </dl>
                                    <button onclick="$('#variant<?php echo e($p->id); ?>').toggleClass('h-auto')" class="btn btn-sm btn-link">Show more</button>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('product.edit',  $p->id)); ?>" class="btn btn-success">Edit</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            <div class="row justify-content-between">
                <div class="col-md-6">
                    <p>Showing <?php echo e($products->firstItem()); ?> to <?php echo e($products->lastItem()); ?> out of <?php echo e($products->total()); ?></p>
                </div>
                <div class="col-md-2">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\mediusware-assessment\resources\views/products/index.blade.php ENDPATH**/ ?>